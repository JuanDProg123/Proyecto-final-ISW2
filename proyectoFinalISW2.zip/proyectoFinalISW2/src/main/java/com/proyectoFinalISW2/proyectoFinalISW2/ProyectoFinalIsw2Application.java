package com.proyectoFinalISW2.proyectoFinalISW2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoFinalIsw2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoFinalIsw2Application.class, args);
	}

}
