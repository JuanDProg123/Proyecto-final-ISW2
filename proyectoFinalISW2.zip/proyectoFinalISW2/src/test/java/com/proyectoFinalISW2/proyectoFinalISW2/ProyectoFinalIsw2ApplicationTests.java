package com.proyectoFinalISW2.proyectoFinalISW2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoFinalIsw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
